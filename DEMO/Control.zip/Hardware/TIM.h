#ifndef _TIM_H_
#define _TIM_H_

#include "sys.h"
void TIM_Init(void);

#endif
