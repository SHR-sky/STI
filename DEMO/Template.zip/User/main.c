#include "sys.h"

int main()
{
	Serial_Init();
	Serial_Printf("Init Finish!\r\n");
	while(1)
	{
		delay_s(1);
		Serial_Printf("Circle:1 \r\n");
	}
}

