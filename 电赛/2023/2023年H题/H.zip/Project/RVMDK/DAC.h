#ifndef __DAC_H__
#define __DAC_H__

#include "sys.h"

void DAC_Init(void);
void Set_Volt(u16 volt);

#endif