ADS1292R���԰���

MODULE ---  STM32
START  ---  PE12
RESET  ---  PE14
DRDY   ---  PB0
MISO   ---  PB14
SCLK   ---  PB13
MOSI   ---  PB15
CS     ---  PB12
